//
// Created by Nadav Koplovich on 11/06/2022.
//

#include "Goblin.h"

Goblin::Goblin():
        BattleCard("Goblin", 6, 2, 10)
{}