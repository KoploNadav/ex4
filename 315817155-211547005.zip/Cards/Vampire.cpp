//
// Created by Nadav Koplovich on 11/06/2022
//

#include "Vampire.h"

Vampire::Vampire():
        BattleCard("Vampire", 10, 2, 10, 1)
{}